using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class spriteManipulator : MonoBehaviour
{
    private static spriteManipulator instance;
    private GameObject sprite1;
    private GameObject sprite2;
    private List<GameObject> spriteList;

    private void Awake()
    {
        instance = this;
        sprite1 = transform.Find("sprite1").gameObject;
        sprite2 = transform.Find("sprite2").gameObject;
        spriteList = new List<GameObject>();
        spriteList.Add(sprite1);
        spriteList.Add(sprite2);

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public static void changeSprite(string[] theSprite)
    {
        for(int i = 0; i < instance.spriteList.Count; i++)
        {
            if(theSprite[i] != "N")
            {
              var theImage = instance.spriteList[i].GetComponent<Image>();
              if(theImage.sprite == null || theImage.sprite.name != theSprite[i])
              {
              theImage.sprite = Resources.Load<Sprite>("testassets/" + theSprite[i]);
              instance.spriteList[i].gameObject.SetActive(true);
              }
            }
            else
            {
             instance.spriteList[i].gameObject.SetActive(false);
            }
        }
    }
}
