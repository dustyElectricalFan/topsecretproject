using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Xml;
using System.IO;
using UnityEngine.SceneManagement;

public class saveLoadManipulator : MonoBehaviour
{

    private static saveLoadManipulator instance;
    private saveRecord[] saveDataRecords =  new saveRecord[6];
    private bool saveLoad;
    private int currentPage = 0;
    public GameObject saveDataprefab1;
    public GameObject saveDataprefab2;
    public GameObject saveDataprefab3;
    public GameObject saveDataprefab4;
    public GameObject saveDataprefab5;
    public GameObject saveDataprefab6;
    private List<GameObject> tempList;
    private byte[] byteArray;
    private int currentText;
  


    private void Awake(){
        instance = this;
        tempList = new List<GameObject> {saveDataprefab1, saveDataprefab2, saveDataprefab3, saveDataprefab4, saveDataprefab5, saveDataprefab6};
  
    }

    class saveRecord
    {
        public string sceneName {get; private set;}
        public string date {get; private set;}
        public int slotNumber {get; private set;}
        public string screen {get; private set;}
        public int currentLine {get; private set;}

        public saveRecord()
        {

        }

        public saveRecord(XmlNode theNode)
        {
            sceneName = theNode.Attributes["sceneName"].Value;
            date = theNode.Attributes["date"].Value;  
            screen = theNode.Attributes["screen"].Value;  
            currentLine = int.Parse(theNode.Attributes["line"].Value); 
        }
        public void setSlot(int num)
        {
          slotNumber = num;
        }
        public void setName(string nam)
        {
          sceneName = nam;
        }
        public void setDate(string dat)
        {
          date = dat;
        }
        public void setScreen(string scre)
        {
          screen = scre;
        }
        public void setLine(int line)
        {
          currentLine = line;
        }
       
    }

    private void populateSaveTable(){
       
       if(!Directory.Exists(Application.persistentDataPath + "/saves"))
       {
         Directory.CreateDirectory(Application.persistentDataPath + "/saves");
       }
       if(!File.Exists(Application.persistentDataPath + "/saves/saveRecords.xml"))
       {
         XmlTextWriter writer = new XmlTextWriter(Application.persistentDataPath + "/saves/saveRecords.xml",System.Text.Encoding.UTF8);
         writer.WriteStartDocument(true);
         writer.Formatting = Formatting.Indented;
         writer.Indentation = 2;
         writer.WriteStartElement("saveRecords");
         for(int i = 1; i < 61; i++)
         {
           writer.WriteStartElement("_" + i.ToString());
           writer.WriteEndElement();
         }
         writer.WriteEndElement();
         writer.WriteEndDocument();
         writer.Close();
       }
       
        XmlDocument storyXml = new XmlDocument();
        storyXml.Load(Application.persistentDataPath + "/saves/saveRecords.xml");
        int xmlCounter = 0;
        foreach (XmlNode node in storyXml.DocumentElement)
        {
          if(node.Attributes["sceneName"] != null)
          {
            saveRecord curLine = new saveRecord(node);
            curLine.setSlot(xmlCounter);
            saveDataRecords[xmlCounter] = curLine;
          }
          xmlCounter += 1;
       }

      instance.changeDataRecords();
       
    }
   
    private void changeDataRecords()
    {
 
      for(int i = 0; i < tempList.Count; i++)
      {
        if(saveDataRecords[currentPage * 6 + i] != null)
        {
        tempList[i].GetComponent<saveDataManipulator>().changeRecord(saveDataRecords[currentPage * 6 + i].sceneName,saveDataRecords[currentPage * 6 + i].screen,saveDataRecords[currentPage * 6 + i].date);
        }
        tempList[i].GetComponent<saveDataManipulator>().setNum(currentPage * 6 + i);

      }
 
    }

    public static void savingOrLoadingRecord(int slotNum)
    {
      if(instance.saveLoad)
      {
        savingRecord(slotNum);
      }
      else
      {
        //instance.StartCoroutine("loadingRecord",slotNum);
        instance.loadingRecord(slotNum);
      }
    }


    public static void savingRecord(int slotNum) 
    {
      System.DateTime theTime = System.DateTime.Now;
      string curDisplay = theTime.Year + "-" + theTime.Month + "-" + theTime.Day + "-" + theTime.Hour + "-" + theTime.Minute + "-" + theTime.Second;
      string displayTime = System.DateTime.Now.ToString();
      if(!Directory.Exists(Application.persistentDataPath + "/screenshots"))
      {
         Directory.CreateDirectory(Application.persistentDataPath + "/screenshots");
      }

      System.IO.File.WriteAllBytes(Application.persistentDataPath + "/screenshots/" + curDisplay + ".png", instance.byteArray);

      if(instance.saveDataRecords[instance.currentPage * 6 + slotNum] == null)
      {
       saveRecord bode = new saveRecord();
       bode.setSlot(slotNum);
       instance.saveDataRecords[instance.currentPage * 6 + slotNum] = bode;
      }

       instance.saveDataRecords[instance.currentPage * 6 + slotNum].setName(SceneManager.GetActiveScene().name);
       instance.saveDataRecords[instance.currentPage * 6 + slotNum].setScreen(curDisplay);
       instance.saveDataRecords[instance.currentPage * 6 + slotNum].setDate(displayTime);
       instance.saveDataRecords[instance.currentPage * 6 + slotNum].setLine(instance.currentText);

       instance.tempList[slotNum].GetComponent<saveDataManipulator>().changeRecord(SceneManager.GetActiveScene().name,curDisplay,displayTime);
       
       XmlDocument storyXml = new XmlDocument();
       storyXml.Load(Application.persistentDataPath + "/saves/saveRecords.xml");
       XmlNode node = storyXml.DocumentElement.ChildNodes[slotNum];
       if(node.Attributes["sceneName"] == null)
       {
         XmlAttribute newattr = storyXml.CreateAttribute("sceneName");
         node.Attributes.Append(newattr);
         newattr = storyXml.CreateAttribute("date");
         node.Attributes.Append(newattr);
         newattr = storyXml.CreateAttribute("screen");
         node.Attributes.Append(newattr);
         newattr = storyXml.CreateAttribute("line");
         node.Attributes.Append(newattr);
       }
       
        node.Attributes["sceneName"].Value = SceneManager.GetActiveScene().name;
        node.Attributes["screen"].Value = curDisplay;
        node.Attributes["date"].Value = displayTime;
        node.Attributes["line"].Value = instance.currentText.ToString();

     storyXml.Save(Application.persistentDataPath + "/saves/saveRecords.xml");
    }

    private void loadingRecord(int slotNum)
    {
      if(instance.saveDataRecords[instance.currentPage * 6 + slotNum] != null)
      {
        GameObject.Find("GameManager").GetComponent<GameManager>().setCurrent(instance.saveDataRecords[instance.currentPage * 6 + slotNum].currentLine,true);
        SceneManager.LoadScene(instance.saveDataRecords[instance.currentPage * 6 + slotNum].sceneName);
        /*
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(instance.saveDataRecords[instance.currentPage * 6 + slotNum].sceneName);
        while (!asyncLoad.isDone)
        {
        yield return null;
        }
        
        yield return new WaitForEndOfFrame();

        GameObject.Find("Canvas").transform.Find("textBox(Clone)").GetComponent<textManipulator>().setCurrentText(currentText);
      */
      }
    }

 
    public static void takePhotoStatic(){
     //instance.takePhoto();
    }
    
    public static void firstTimeOpen()
    {
      instance.populateSaveTable();
    }

    public static void saveGame(byte[] byteArr, int curText)
    {
      instance.byteArray = byteArr;
      instance.currentText = curText;
      instance.gameObject.SetActive(true);
      instance.saveLoad = true;
    }
    
    public static void loadGame()
    {
      instance.gameObject.SetActive(true);
      instance.saveLoad = false;
    }

    public static void startSaveLoad()
   {
       instance.gameObject.SetActive(true);
   }

}
