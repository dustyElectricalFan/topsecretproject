using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class saveDataManipulator : MonoBehaviour
{
    private string sceneName;
    private string date;
    private string screenshot;
    private bool saveLoad;
    private static saveDataManipulator instance;

    private void Awake()
    {
        instance = this;
    }
    public void changeRecord(string newScene, string newDate, string newShot, bool theMode)
   {
        instance.sceneName = newScene;
        instance.date = newDate;
        instance.screenshot = newShot;
        instance.saveLoad = theMode;
   } 

}
