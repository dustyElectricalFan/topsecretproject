using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Xml;


public class saveLoadManipulator : MonoBehaviour
{

    private static saveLoadManipulator instance;
    private saveRecord[] saveDataRecords =  new saveRecord[4];
    private bool saveLoad;
    private int currentPage = 0;
    public GameObject saveDataprefab1;
    public GameObject saveDataprefab2;
    public GameObject saveDataprefab3;
    public GameObject saveDataprefab4;
    public GameObject saveDataprefab5;
    public GameObject saveDataprefab6;


    private void Awake(){
        instance = this;
  
    }

    class saveRecord
    {
        public string sceneName {get; private set;}
        public string date {get; private set;}
        public string screenshot {get; private set;}

        public saveRecord(XmlNode theNode)
        {
            sceneName = theNode.Attributes["sceneName"].Value;
            date = theNode.Attributes["date"].Value;
            screenshot = theNode["screenshot"].InnerText;
     
        }
    }

    private void populateSaveTable(){
        TextAsset xmldoc = Resources.Load<TextAsset>("Story/saveRecords");
        XmlDocument storyXml = new XmlDocument();
        storyXml.LoadXml(xmldoc.text);
        int xmlCounter = 0;
        foreach (XmlNode node in storyXml.DocumentElement)
        {
          if(node.Name != "nullrecord")
          {
            saveRecord curLine = new saveRecord(node);
            saveDataRecords[xmlCounter] = curLine;
          }
          xmlCounter += 1;
       }

      instance.changeDataRecords();
       
    }
   
    private void changeDataRecords()
    {
 
      List<GameObject> tempList = new List<GameObject>{saveDataprefab1, saveDataprefab2, saveDataprefab3, saveDataprefab4, saveDataprefab5, saveDataprefab6};
      for(int i = 0; i < tempList.Count; i++)
      {
        if(saveDataRecords[currentPage * 6 + i] != null)
        {
        tempList[i].GetComponent<saveDataManipulator>().changeRecord(saveDataRecords[currentPage * 6 + i].sceneName,saveDataRecords[currentPage * 6 + i].date,saveDataRecords[currentPage * 6 + i].screenshot,saveLoad);
        }
      }
 
    }
    

    public static void firstTimeOpen()
    {
      instance.populateSaveTable();
    }

    public static void saveGame()
    {
      instance.gameObject.SetActive(true);
      instance.saveLoad = true;
    }

    public static void loadGame()
    {
      instance.gameObject.SetActive(true);
      instance.saveLoad = false;
    }

    public static void startSaveLoad()
   {
       instance.gameObject.SetActive(true);
   }

}
