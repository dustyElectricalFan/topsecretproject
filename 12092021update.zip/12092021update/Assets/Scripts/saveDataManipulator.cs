using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;


public class saveDataManipulator : MonoBehaviour
{
   
    private Image screenshot;
    private bool saveLoad;
    private saveDataManipulator instance;
    private Text sceneName;
    private Text date;
    private int slotNumber;
    public GameObject saveSlots;
    

    private void Awake()
    {
         instance = this;
         sceneName = transform.Find("chapterText").GetComponent<Text>();
         date = transform.Find("timeText").GetComponent<Text>();
         screenshot = transform.Find("saveDataImage").GetComponent<Image>();
    }
    public void changeRecord(string newScene, string newDate, bool theMode)
   {
        instance.saveLoad = theMode;
        instance.sceneName.text = newScene;
        instance.date.text = newDate;
        if(System.IO.File.Exists(Application.persistentDataPath + "/screenshots/" + newDate + ".png"))
        {
        byte[] byteArray = System.IO.File.ReadAllBytes(Application.persistentDataPath + "/screenshots/" + newDate + ".png");
        Texture2D texture = new Texture2D(418,207);
        texture.LoadImage(byteArray);
        Sprite sprit = Sprite.Create(texture, new Rect(0,0,texture.width,texture.height), new Vector2(0.5f, 0.5f));
        var tempColor = screenshot.color;
        tempColor.a = 255f;
        screenshot.color = tempColor;
        instance.screenshot.sprite = sprit;
        }
   }

   public void setNum(int num)
   {
     instance.slotNumber = num;
   }

   public void saveCurRecord()
   {
    saveLoadManipulator.savingRecord(slotNumber);
   } 

}
