using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class savePageButtonManipulator : MonoBehaviour
{
    private Image background;
    private savePageButtonManipulator instance;
    private Text buttonText;
    public GameObject saveSlots;


    private void Awake()
    {
        instance = this;
        background = this.GetComponent<Image>();
        buttonText = transform.Find("Text").GetComponent<Text>();
    }
   
   public void selectPage()
   {
       background.sprite = Resources.Load<Sprite>("testassets/Site-favicon-1");
       saveLoadManipulator.changePage(int.Parse(buttonText.text) - 1);
   }

   public void deselectPage()
   {
       background.sprite = Resources.Load<Sprite>("testassets/deselected");
   }

   public void assignText(string newText)
   {
       buttonText.text = newText;
   }
}
