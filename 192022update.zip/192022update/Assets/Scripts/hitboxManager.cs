using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hitboxManager : MonoBehaviour
{
    [SerializeField]
    private PolygonCollider2D[] colliders;

    private int currIndex = 0; 

    public void setCollider(int spriteNum)
    {
        colliders[currIndex].enabled = false;
        currIndex = spriteNum;
        colliders[currIndex].enabled = true;

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
