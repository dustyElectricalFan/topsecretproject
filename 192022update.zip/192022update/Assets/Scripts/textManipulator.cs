using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Xml;

public class textManipulator : MonoBehaviour
{

    private Text dialouge;
    private Text speaker;
    private bool isRunning;
    private bool isAuto = false;
    private static textManipulator instance;
    
    
    public GameObject prefab;
    public GameObject canvasPrefab;
    public GameObject sprite1;
    public GameObject sprite2;
    public GameObject choice1;
    public GameObject choice2;
    public GameObject choice3;
    private Canvas canvas;


    private GameObject logPrefab;
    private List<Line> chapter; 
    private List<List<string>> log;
    private int curText = 0;


    private GameObject saveLoadPre; 
    public GameObject saveLoadPrefab;

    private List<GameObject> buttonList;
    private string[] spritesList;
    private string[] choiceList;
    

    private Canvas theCanvas
    {
      get{
          if(canvas == null)
          {
              canvas = FindObjectOfType<Canvas>();
          if(canvas == null)
          {
              canvas = Instantiate(canvasPrefab).GetComponent<Canvas>();
          }
          }
          return canvas;
      }
    }

    class Line
    {
        public string lineID {get; private set;}
        public string speaker {get; private set;}
        public string theLine {get; private set;}
        public string[] sprite {get; private set;}
        public string[] choices {get; private set;}
        public string[] jump {get; private set;}
      

        public Line(XmlNode theNode)
        {
            lineID = theNode.Attributes["ID"].Value;
            speaker = theNode.Attributes["speaker"].Value;
            theLine = theNode["theLine"].InnerText;
            if(theNode["sprite"] != null)
            {
            sprite = theNode["sprite"].InnerText.Split(',');
            }
            else
            {
                sprite = null;
            }
            if(theNode["choices"] != null)
            {
            choices = theNode["choices"].InnerText.Split(',');
            }
            else
            {
                choices = null;
            }
            if(theNode["jump"] != null)
            {
            jump = theNode["jump"].InnerText.Split(',');
            }
            else
            {
                jump = null;
            }
            
        }
    }
    
    private void Awake(){
        instance = this;
        buttonList = new List<GameObject>{choice1,choice2,choice3};
        populateDialouge();
    }

    void Start()
    {
        spriteManipulator.setList(spritesList);
        curText = GameObject.Find("GameManager").GetComponent<GameManager>().getCurrent();
        if(curText < 0)
        {
            curText = 0;
            GameObject.Find("GameManager").GetComponent<GameManager>().setCurrent(0,false);
            instance.startTyping(chapter[curText].theLine);
        }
        else
        {
           GameObject.Find("GameManager").GetComponent<GameManager>().setCurrent(0,false);
           dialouge.text = chapter[curText].theLine;
           speaker.text = chapter[curText].speaker;
           changeSprites();
           checkChoice();
        }
    }

    private void populateDialouge()
    {
        dialouge = transform.Find("dialougeText").GetComponent<Text>();
        speaker = transform.Find("speakerimg/speakername").GetComponent<Text>();
        dialouge.text = "";
        speaker.text = "";
        chapter = new List<Line>();
        log = new List<List<string>>();
        TextAsset xmldoc = Resources.Load<TextAsset>("Story/new1");
        XmlDocument storyXml = new XmlDocument();
        storyXml.LoadXml(xmldoc.text);
        
        string tempSpritesList = storyXml.DocumentElement.ChildNodes[0].InnerText;
        string tempChoiceList = storyXml.DocumentElement.ChildNodes[1].InnerText;
        spritesList = tempSpritesList.Split(',');
        choiceList = tempChoiceList.Split(',');
        for(int i = 2; i < storyXml.DocumentElement.ChildNodes.Count; i++)
        {
            Line curLine = new Line(storyXml.DocumentElement.ChildNodes[i]);
            chapter.Add(curLine);
        }
     
    }

    private void startTyping(string enterText)
    {
       StartCoroutine("TypeText",enterText);
    }
    
    IEnumerator TypeText(string toType)
    {
        isRunning = true;
        speaker.text = chapter[curText].speaker;

        
        changeSprites();


        foreach (char c in toType)
        {
            dialouge.text += c;
            yield return new WaitForSeconds(0.020f);

        }
        isRunning = false;
    }

    private void checkChoice()
    {
        if(chapter[curText].choices != null)
        {
            bool tempbool = isAuto;
            isAuto = false;
            transform.Find("advanceButton").GetComponent<Button>().interactable = false;
    
            for(int i = 0; i < chapter[curText].choices.Length; i++)
            {
                buttonList[i].gameObject.SetActive(true);
                buttonList[i].GetComponent<choiceManipulator>().setChoice(chapter[curText].choices[i],i,tempbool);
            }
        }
    }

    public static void advanceChoice(int chosen, bool tempbool)
    {
        foreach(GameObject obj in instance.buttonList)
        {
            obj.gameObject.SetActive(false);
        }
        instance.curText = int.Parse(instance.chapter[instance.curText].jump[chosen]);
        instance.dialouge.text = ""; 
        instance.transform.Find("advanceButton").GetComponent<Button>().interactable = true;
        instance.startTyping(instance.chapter[instance.curText].theLine);
        if(tempbool)
        {
          instance.Invoke("autoText", 1f);
        }
    }
    /*
    private IEnumerator autoAfterChoice()
    {
        yield return new WaitForSeconds(1f);
        autoText();
    }
    */

    public void publicAdvanceText()
    {
        if(isAuto)
        {
            isAuto = false;
        }
        advanceText();
    }

    public void changeSprites()
    {
        if(chapter[curText].sprite != null)
        {
            spriteManipulator.changeSprite(chapter[curText].sprite);
        }
    }

    public void advanceText()
    {
        if(isRunning)
        {
            StopCoroutine("TypeText");
            dialouge.text = chapter[curText].theLine;
            isRunning = false;
        }
        else{
            List<string> newEntry = new List<string>();
            newEntry.Add(chapter[curText].speaker);
            newEntry.Add(chapter[curText].theLine);
            log.Add(newEntry);
            dialouge.text = "";
            curText += 1;
            isRunning = true;
            StartCoroutine("TypeText",chapter[curText].theLine);
            }
       checkChoice();
    }

    public void autoText()
    {
        if(isAuto)
        {
         isAuto = false;
         StopCoroutine("autoTyper");
        }
        else 
        {
         isAuto = true;
         StartCoroutine("autoTyper");
        } 
    }

    public void setCurrentText(int currentText)
    {
        instance.curText = currentText;
        
        if(isRunning)
        {
            StopCoroutine("TypeText");
            isRunning = false;
        }
        
        dialouge.text = chapter[curText].theLine;
        speaker.text = chapter[curText].speaker;
        changeSprites();
        checkChoice();
     
    }



    IEnumerator autoTyper()
    {
        while(isRunning)
        {
            yield return new WaitForSeconds(0.1f);
        }
     
        while(isAuto && curText < chapter.Count - 1)
        {
           advanceText();
           while(isRunning)
           {
            yield return new WaitForSeconds(0.1f);
           }
           yield return new WaitForSeconds(1f);
        }
        
    }

    public void seeLog()
    {
     
     if(logPrefab == null)
       {
         logPrefab = Instantiate(prefab, theCanvas.transform);
         logManipulator.displayLogStatic(log);
       }
       else
       {
           logManipulator.pullUpDisplayStatic();
           logManipulator.displayLogStatic(log);
       }
     
    }

    public static void staticSaveProgress()
    {
        instance.StartCoroutine("saveProgress");
    }


    public IEnumerator saveProgress()
    {

        yield return new WaitForEndOfFrame();
        Texture2D renderRes = new Texture2D(Screen.width, Screen.height, TextureFormat.ARGB32, false);
        Rect rect = new Rect(0,0,Screen.width,Screen.height);
        renderRes.ReadPixels(rect,0,0);
        byte[] byteArray = renderRes.EncodeToPNG();
     
        if(saveLoadPre == null)
       {
         saveLoadPre = Instantiate(saveLoadPrefab, theCanvas.transform);
         saveLoadManipulator.firstTimeOpen();
       }
        
        saveLoadManipulator.saveGame(byteArray, curText);
       
    }

    public void LoadProgress()
    {
        if(saveLoadPre == null)
       {
         saveLoadPre = Instantiate(saveLoadPrefab, theCanvas.transform);
         saveLoadManipulator.firstTimeOpen();
       }
        saveLoadManipulator.loadGame();
       
    }


    void Update()
    {
    
    }
}
