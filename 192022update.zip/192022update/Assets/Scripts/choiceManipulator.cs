using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class choiceManipulator : MonoBehaviour
{

    private choiceManipulator instance;
    private Text choice;
    private int choiceNum;
    private bool isAuto;

    private void Awake()
    {
         instance = this;
         choice = transform.Find("choiceText").GetComponent<Text>();
    }

    public void setChoice(string newChoice, int newNum, bool tempbool)
    {
         instance.choice.text = newChoice;
         instance.choiceNum = newNum;
         instance.isAuto = tempbool;
    }

    public void choseThis()
    {
        textManipulator.advanceChoice(choiceNum, isAuto);

    }

}
